# PixelHub
Projecto final para el Certificado de profesionalidad en desarrollo en ambito web subvencionado por el SEPE.

PixelHub nace de la necesidad de un espacio seguro hecho por geeks para geeks, donde poder publicar contenido de valor para aficionados de la cultura pop en sus extensiones, dando una interfaz intuitiva a los usuarios.

El objetivo principal de este blog, es poder ofrecer a nuevos aficionados de la cultura pop, contenido relevante y gestionado por la misma comunidad sin muchas restricciones por lo que esta tiene libertad al momento de crear el contenido de la plataforma.

## Diseño Base

### Descripción del Diseño Inicial en Canva

El diseño inicial del blog "PixelHub" fue creado utilizando Canva, una herramienta de diseño gráfico en línea. El enfoque principal fue crear una interfaz de usuario limpia y moderna, con un esquema de colores oscuros y acentos en cian, para proporcionar una experiencia visual atractiva. Las diferentes secciones están bien definidas para mejorar la navegación y la usabilidad, facilitando a los usuarios encontrar y consumir contenido.

### Capturas de Pantalla del Diseño

Las capturas de pantalla adjuntas muestran varias secciones del diseño inicial:

1. **Página Principal**: Muestra una galería de artículos destacados con imágenes atractivas y etiquetas superpuestas.
2. **Página de Inicio de Sesión**: Formulario sencillo para que los usuarios ingresen su nombre de usuario y contraseña.
3. **Página de Registro**: Formulario para nuevos usuarios con campos para nombre de usuario, email, y contraseña.
4. **Perfil del Usuario**: Detalles del perfil con opción para editar información y cerrar sesión.
5. **Página de Artículos**: Lista de artículos con miniaturas e información básica.
6. **Página de Redacción de Artículos**: Formulario para que los usuarios creen y publiquen nuevos artículos.

Estas capturas ilustran el diseño cohesivo y funcional pensado para una experiencia de usuario intuitiva y agradable.

![pixelHubCanva.png](PixelHub%20984d36efd9004270bc5dff353f2b0e53/pixelHubCanva.png)

## Metodología de Trabajo

### Descripción de la Metodología Kanban

Para la gestión del proyecto "PixelHub", hemos adoptado la metodología Kanban, que es un enfoque ágil de desarrollo de software. Kanban es una metodología visual que se centra en la gestión del trabajo a medida que pasa por un proceso. Su objetivo principal es mejorar la eficiencia y la flexibilidad del equipo, permitiéndonos responder de manera rápida a los cambios y asegurar la entrega continua de valor.

En un sistema Kanban, el trabajo se representa mediante tarjetas (o "tickets") que se mueven a través de varias columnas en un tablero, cada una representando una etapa del proceso de desarrollo. Las columnas típicas en un tablero Kanban pueden incluir "Por Hacer", "En Proceso", y "Hecho". Este enfoque nos permite visualizar el flujo de trabajo y limitar el trabajo en progreso para identificar y eliminar cuellos de botella.

### Detalles del Uso de Trello

Para implementar la metodología Kanban en nuestro proyecto, utilizamos Trello, una herramienta en línea de gestión de proyectos que facilita la colaboración y la organización visual de tareas. A continuación, se detallan los aspectos clave de cómo utilizamos Trello:

1. **Tablero de Proyecto**:
    - Creamos un tablero específico para el proyecto "Blog Geek" en Trello.
    - Este tablero contiene varias listas que representan las diferentes fases del proyecto:  "ToDo", "En Proceso", "Revisión", y "Hecho".
2. **Tarjetas de Tareas**:
    - Cada tarea o funcionalidad del proyecto se representa mediante una tarjeta en el tablero.
    - Las tarjetas contienen descripciones detalladas de la tarea, incluyendo los requisitos, criterios de aceptación, y cualquier archivo o enlace relevante.
3. **Asignación y Colaboración**:
    - Las tarjetas se asignan a los miembros del equipo responsables de su ejecución.
    - Utilizamos etiquetas de colores para categorizar las tareas según su prioridad o tipo (por ejemplo, desarrollo, diseño, pruebas).
    - Los miembros del equipo pueden comentar en las tarjetas para discutir detalles, compartir actualizaciones o resolver dudas.
4. **Flujo de Trabajo**:
    - Las tarjetas se mueven de una lista a otra a medida que avanzan por las diferentes etapas del proceso de desarrollo.
    - Esto permite al equipo tener una visión clara del estado actual de cada tarea y del progreso general del proyecto.
5. **Revisiones y Retroalimentación**:
    - Utilizamos la lista "En Revisión" para tareas que requieren evaluación antes de ser marcadas como completadas.
    - Los revisores pueden proporcionar retroalimentación directamente en la tarjeta, asegurando que todas las observaciones sean abordadas antes de finalizar la tarea.

El uso de Trello y la metodología Kanban nos ha permitido trabajar de manera más organizada y eficiente, facilitando la colaboración y asegurando que todos los miembros del equipo estén alineados con los objetivos y el progreso del proyecto.

## Descripción del Proyecto

### Tecnologías Utilizadas

Para el desarrollo del blog "PixelHub", se utilizaron las siguientes tecnologías:

- **Lenguajes de Programación**: PHP, HTML, CSS, JavaScript
- **Frameworks y Librerías**: Bootstrap (para estilos y diseño responsivo), Parsedown (para parseo de Markdown)
- **Base de Datos**: MySQL
- **Control de Versiones**: Git y GitHub
- **Herramientas de Colaboración**: Trello (para gestión de tareas)

### Funcionalidades Principales del Blog

1. **Publicación de Artículos**:
    - Los usuarios pueden escribir y publicar artículos en formato Markdown, que luego se renderizan en HTML.
2. **Gestión de Usuarios**:
    - Funcionalidades de registro e inicio de sesión para los usuarios.
    - Perfil de usuario donde se puede actualizar la información personal.
3. **Navegación Intuitiva**:
    - Barra de navegación que permite acceder fácilmente a las diferentes secciones del blog.
    - Página principal con una galería de categorías destacadas.
4. **Interfaz de Redacción**:
    - Formulario para la creación de nuevos artículos con campos para el título, categoría, descripción y contenido.

## Implementación

### Estructura del Código

El proyecto "GeekBlog" se organiza en varios directorios y archivos, cada uno con una función específica:

![Untitled](PixelHub%20984d36efd9004270bc5dff353f2b0e53/Untitled.png)

### Componentes Principales y su Funcionalidad

1. **index.php**:
    - Funciona como la página principal del blog.
    - Funcionalidad: Carga las categorías autorizadas para las publicaciones con un diseño atractivo y muestra la personalidad del sitio en su mejor esplendor.
2. **db_conn/**:
    - Contiene los datos necesarios para la conexión con la base de datos.
    - Funcionalidad: Facilita la interacción con la base de datos MySQL.
3. **functions/**:
    - Incluye funciones PHP reutilizables.
    - Funcionalidad: Realiza operaciones comunes como la validación de datos y la creación y manejo de variables de sesión.
4. **pages/**:
    - Contiene archivos que representan las diferentes páginas del blog.
    - Funcionalidad: Proporciona el contenido para cada sección del sitio, como la página de las publicaciones conocida como feed, contacto, perfil, etc.
5. **lib/parsedown-1.7.4**:
    - Librería para convertir texto Markdown en HTML.
    - Funcionalidad: Permite que los usuarios escriban publicaciones en Markdown, que luego se renderizan en HTML.

## Desafíos y Soluciones

### Desafíos Iniciales

Al iniciar el proyecto "PixelHub", nos enfrentamos a varios desafíos significativos:

1. **Falta de experiencia en trabajos colaborativos**:
    - Muchos miembros del equipo no tenían experiencia previa en proyectos colaborativos, lo que dificultaba la coordinación y la comunicación efectiva.
2. **Ausencia de un sistema de guía para segmentar y delegar tareas**:
    - No contábamos con un marco estructurado para dividir y asignar el trabajo, lo que generaba confusión y duplicación de esfuerzos.
3. **Incertidumbre en la elección del proyecto**:
    - No estábamos seguros de qué tipo de proyecto desarrollar, lo que retrasó el inicio del trabajo y la planificación.

### Soluciones Implementadas

Para abordar estos desafíos, implementamos las siguientes estrategias:

1. **Selección del Proyecto**:
    - Decidimos trabajar en un proyecto con el cual nos sintiéramos identificados y que fuera realizable dentro del plazo de entrega. Optamos por un blog debido a nuestra fascinación compartida por la cultura POP y la necesidad de utilizar bases de datos, lo cual abrió un abanico de opciones interesantes.
2. **Establecimiento de Herramientas y Acuerdos de Desarrollo**:
    - Fijamos el uso de GitHub y Git para la gestión del código y la colaboración.
    - Elegimos trabajar con PHP, el lenguaje de programación que habíamos aprendido durante el curso.
    - Decidimos utilizar librerías de estilo como Bootstrap para asegurar coherencia visual en todo el proyecto.
    - Implementamos el modelo Vista-Controlador (MVC) para gestionar las interacciones de los usuarios de manera estructurada y eficiente.
3. **Segmentación y Delegación de Tareas**:
    - Utilizamos Trello para segmentar y delegar tareas de manera eficiente. Esto nos permitió tener una visión clara del progreso y asegurar que cada miembro del equipo supiera exactamente qué hacer.

### Proceso de Crecimiento

A lo largo del proyecto, nos enfocamos en aprender y mejorar continuamente. Con dedicación y esfuerzo, superamos nuestros desafíos iniciales, fomentando nuestro crecimiento profesional y logrando completar el proyecto "PixelHub" de manera exitosa.

## Conclusiones

### Resultados Obtenidos

Al concluir el proyecto "PixelHub", logramos desarrollar una plataforma funcional y visualmente atractiva para compartir artículos sobre la cultura POP. Cumplimos con todos los requisitos del proyecto, incluyendo la integración de bases de datos, la implementación del modelo Vista-Controlador (MVC) y el uso de librerías de estilo como Bootstrap. Además, mejoramos significativamente nuestra capacidad de trabajar en equipo y gestionar proyectos colaborativos.

### Lecciones Aprendidas

1. **Importancia de la Planificación y la Comunicación**:
    - Aprendimos que una planificación clara y una comunicación efectiva son esenciales para el éxito de cualquier proyecto colaborativo. Herramientas como Trello y GitHub fueron fundamentales para organizar nuestras tareas y mantener a todos los miembros del equipo informados.
2. **Flexibilidad y Adaptación**:
    - Nos adaptamos a los desafíos y aprendimos a ser flexibles en nuestro enfoque, lo que nos permitió superar obstáculos y cumplir con los plazos establecidos.
3. **Valor del Aprendizaje Continuo**:
    - Nos dimos cuenta de la importancia de estar dispuestos a aprender y mejorar constantemente. La dedicación y el esfuerzo para adquirir nuevas habilidades y conocimientos fueron clave para nuestro éxito.

### Futuro del Proyecto y Posibles Mejoras

El futuro de "PixelHub" es prometedor y consideramos varias posibles mejoras:

1. **Funcionalidades Adicionales**:
    - Integración de una sección de comentarios para fomentar la interacción entre los usuarios.
    - Implementación de un sistema de calificación y recomendaciones personalizadas basadas en las preferencias de los usuarios.
2. **Optimización de Rendimiento**:
    - Mejorar la eficiencia de la base de datos y optimizar el tiempo de carga de la página para una mejor experiencia de usuario.
3. **Expansión del Contenido**:
    - Ampliar el alcance del contenido para incluir más temas relacionados con la cultura POP y atraer a una audiencia más amplia.
4. **Mejoras en la Interfaz de Usuario**:
    - Refinar el diseño visual y la usabilidad del sitio basado en la retroalimentación de los usuarios para asegurar que sea intuitivo y atractivo.

En resumen, "PixelHub" no solo fue un proyecto exitoso en términos de resultados técnicos y de colaboración, sino que también nos proporcionó valiosas lecciones y un camino claro para futuras mejoras y expansión.
