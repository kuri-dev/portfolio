<?php
$sname="localhost";
$uname="root";
$password="";
$db_name="geekblog";

try{
     $conn= new PDO("mysql:host=$sname;dbname=$db_name; charset=utf8mb4",$uname,$password);

    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    

}catch(PDOException $e){
   echo "Connexió fallida: ". $e->getMessage();
}
?>