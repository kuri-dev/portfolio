<?php
include "./sections/headers.php";
?>
<body>
    <?php
    include "./pages/landing.php";
    ?>
</body>

</html>