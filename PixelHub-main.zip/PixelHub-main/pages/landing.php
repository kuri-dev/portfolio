<?php
require __DIR__ . "/../sections/hero.php";
require __DIR__ . "/../sections/footer.php";?>
<style>
    @import "./css/landing.css";
@import "./css/variables.css";
    <?php echo include "./css/header.css"; ?>

    <?php echo include "./css/footer.css"; ?>
</style>
