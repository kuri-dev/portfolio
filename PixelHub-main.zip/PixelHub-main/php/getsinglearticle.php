<?php
function getSingleArticle($id,$conn) {
$sql = "SELECT 
a.id AS article_id,
a.title,
a.content,
a.created_at,
a.img_url,
a.figcaption,
u.id AS user_id,
u.username,
u.email,
u.profile_picture,
c.id AS category_id,
c.cat AS category,
c.icon_url AS category_icon
FROM 
articles a
JOIN 
users u ON a.user_id = u.id
JOIN 
categories c ON a.category_id = c.id
WHERE 
a.id = :article_id;
";
$stmt = $conn->prepare($sql);
$stmt->execute([':article_id' => $id]);
return $stmt->fetch(PDO::FETCH_ASSOC);
}
?>