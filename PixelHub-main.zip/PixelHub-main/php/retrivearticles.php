<?php
$sql = "SELECT 
            a.id,
            u.username,
            a.title,
            a.content,
            c.cat AS category,
            a.img_url AS article_image,
            a.created_at,
            c.icon_url AS category_image
        FROM 
            articles a
        JOIN 
            users u ON a.user_id = u.id
        JOIN 
            categories c ON a.category_id = c.id";

$stmt = $conn->query($sql);
$all_articles = $stmt->fetchAll();
?>