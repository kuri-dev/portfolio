<?php
$sql = "SELECT id, cat FROM categories";
$stmt = $conn->query($sql);
$all_categories = $stmt->fetchAll();?>