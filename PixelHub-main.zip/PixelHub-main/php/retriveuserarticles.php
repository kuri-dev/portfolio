<?php
$sql = "SELECT 
            a.id,
            u.username,
            u.email,
            u.profile_picture,
            a.title,
            a.content,
            c.cat AS category,
            a.img_url AS article_image,
            a.figcaption,
            a.created_at,
            c.icon_url AS category_image
        FROM 
            articles a
        JOIN 
            users u ON a.user_id = u.id
        JOIN 
            categories c ON a.category_id = c.id
        WHERE
            u.id = :userID";

$stmt = $conn->prepare($sql);
$stmt->bindParam(':userID', $_SESSION['userID'], PDO::PARAM_INT);
$stmt->execute();
$user_articles = $stmt->fetchAll();
?>
