<?php
session_start();

if (isset($_POST['create-art'])) {
    include "../functions/funcions.php";
    include "../db_conn/config.php";
    
    $title = neteja($_POST['title']);
    $content = neteja($_POST['content']);
    $category_id = neteja($_POST['category_id']);
    $figcaption = neteja($_POST['figcaption']);
    $article_picture = $_FILES['article_picture'];

    // Validar entradas
    if (empty($title)) {
        header("Location:../pages/article_form.php?error=No%20has%20colocado%20el%20título&content=$content&category_id=$category_id&figcaption=$figcaption");
        exit();
    } elseif (empty($content)) {
        header("Location:../pages/article_form.php?error=No%20has%20colocado%20el%20contenido&title=$title&category_id=$category_id&figcaption=$figcaption");
        exit();
    } elseif ($article_picture['error'] !== UPLOAD_ERR_OK) {
        header("Location:../pages/article_form.php?error=Error%20al%20subir%20la%20imagen&title=$title&content=$content&category_id=$category_id&figcaption=$figcaption");
        exit();
    } else {
        $article_picture_name = basename($article_picture['name']);
        $article_picture_tmp_name = $article_picture['tmp_name'];
        $article_picture_size = $article_picture['size'];
        $article_picture_error = $article_picture['error'];
        $article_picture_type = $article_picture['type'];
        $article_picture_ext = strtolower(pathinfo($article_picture_name, PATHINFO_EXTENSION));
        $allowed_ext = array('jpg', 'jpeg', 'png', 'gif');

        if (in_array($article_picture_ext, $allowed_ext)) {
            $article_picture_new_name = uniqid('', true) . "." . $article_picture_ext;
            $article_picture_destination = "../uploads/articles/" . $article_picture_new_name;

            if (move_uploaded_file($article_picture_tmp_name, $article_picture_destination)) {
                // Insertar el artículo en la base de datos
                $sql = "INSERT INTO articles (user_id, title, content, category_id, img_url, figcaption) VALUES (?, ?, ?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                try {
                    $stmt->execute([$_SESSION['userID'], $title, $content, $category_id, $article_picture_destination, $figcaption]);
                    header("Location: ../pages/write-article.php?success=Artículo%20publicado%20con%20éxito");
                    exit();
                } catch (Exception $e) {
                    header("Location:../pages/write-article.php?error=Hemos%20tenido%20un%20error&title=$title&content=$content&category_id=$category_id&figcaption=$figcaption");
                    exit();
                }
            } else {
                header("Location:../pages/write-article.php?error=Error%20al%20guardar%20la%20imagen&title=$title&content=$content&category_id=$category_id&figcaption=$figcaption");
                exit();
            }
        } else {
            header("Location:../pages/write-article.php?error=Extensión%20de%20imagen%20no%20admitida&title=$title&content=$content&category_id=$category_id&figcaption=$figcaption");
            exit();
        }
    }
} else {
    header("Location:../index.php");
    exit();
}
?>
