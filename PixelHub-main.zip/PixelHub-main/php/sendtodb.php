<?php

session_start();
if (isset($_POST['contact-us'])) {
    include "../functions/funcions.php";
    include "../db_conn/config.php";
    $motivo = neteja($_POST['motivo']) ;
    $desarrollo = neteja($_POST['desarrollo']);

    if (empty($motivo)) {
        header("Location:../pages/article_form.php?error=No%20has%20colocado%20el%20título&motivo=$motivo&desarrollo=$desarrollo");
        exit();
    } elseif (empty($desarrollo)) {
        header("Location:../pages/article_form.php?error=No%20has%20colocado%20el%20contenido&motivo=$motivo&desarrollo=$desarrollo");
        exit();
    } else {
        $sql = "INSERT INTO contacts (motivo, desarrollo,user_mail) VALUES (?, ?, ?)";
        $stmt = $conn->prepare($sql);
    
        try {
            // Execute the statement with sanitized data
            $stmt->execute([$motivo, $desarrollo,$_SESSION['usermail']]);
    
            // Success message (consider redirecting or displaying a message)
            echo "Gracias por contactarnos. ¡Tu mensaje ha sido enviado!"; // Modify as needed
            header("Location: ../pages/contacto.php?success=Mensaje%20guardado%20con%20éxito");
            exit();
    
        } catch (Exception $e) {
            // Error message
            header("Location:../pages/write-article.php?error=Hemos%20tenido%20un%20error&motivo=$motivo&desarrollo=$desarrollo");
                    exit();
        }
    }

} else {
    // If form not submitted, redirect or display an error message
    header("Location: ../pages/contacto.php?error=Formulario%20no%20enviado"); // Modify as needed
    exit();
}

?>