<?php 
session_start();
if(isset($_POST['unom']) && isset($_POST['pass'])){
    include "../db_conn/config.php";
    include "../functions/funcions.php";
    $unom=neteja($_POST['unom']);
    $pass=neteja($_POST['pass']);
    if(empty($unom)){
        $em="No has posat el nom d'usuari";
        header("Location:../pages/auth/login.php?error=$em");
        exit();
    }elseif (empty($pass)){
        $em="No has posat la contrasenya";
        header("Location:../pages/auth/login.php?error=$em&unom=$unom");
        exit();
    }else{
        $sql="SELECT * FROM users WHERE  username= ?";
        $stmt=$conn->prepare($sql);
        $stmt->execute([$unom]);
        if($stmt->rowCount()===1){
            $usuari=$stmt->fetch();
            $nombreUsuario=$usuari['username'];
            $emailUsuario=$usuari['email'];
            $contrasenya=$usuari['password'];
            $id=$usuari['id'];
            if($unom===$nombreUsuario){
                if(password_verify($pass,$contrasenya)){
                    logIntoSession($nombreUsuario, $emailUsuario, $id,$usuari['profile_picture']);
                    header("Location:../pages/articles/multiple-articles.php");
                    exit();
                }else{
                    $em="Usuari i/o contrasenya incorrecte";
                    header("Location:../pages/auth/login.php?error=$em&unom=$unom");
                    exit();
                }
            }else{
                    $em="Usuari i/o contrasenya incorrecte";
                    header("Location:../pages/auth/login.php?error=$em&unom=$unom");
                    exit();
            }

        }
        else{
            $em= "Usuari i/o contrasenya incorrectes";
            header("Location:../pages/auth/login.php?error=$em&unom=$unom");
        }
    }

}else{
    header("Location:../index.php?error=No has iniciat sessió");
}
?>