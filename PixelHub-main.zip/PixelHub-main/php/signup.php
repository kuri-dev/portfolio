<?php
if (isset($_POST['create'])) {
    include "../functions/funcions.php";
    include "../db_conn/config.php";
    
    $username = neteja($_POST['username']);
    $email = neteja($_POST['email']);
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    $password = neteja($_POST['password']);
    $confirm_password = neteja($_POST['confirm_password']);
    $profile_picture = $_FILES['profile_picture'];

    if (empty($username)) {
        header("Location:../pages/auth/signup.php?error=No%20has%20colocado%20tu%20usuario&email=$email");
        exit();
    } elseif (empty($email)) {
        header("Location:../pages/auth/signup.php?error=No%20has%20colocado%20tu%20email&username=$username");
        exit();
    } elseif (empty($password)) {
        header("Location:../pages/auth/signup.php?error=No%20has%20colocado%20tu%20contraseña&username=$username&email=$email");
        exit();
    } elseif ($password !== $confirm_password) {
        header("Location:../pages/auth/signup.php?error=Las%20contraseñas%20no%20coinciden&username=$username&email=$email");
        exit();
    } elseif ($profile_picture['error'] !== UPLOAD_ERR_OK) {
        header("Location:../pages/auth/signup.php?error=Error%20al%20subir%20tu%20foto%20de%20perfil&username=$username&email=$email");
        exit();
    } else {
        $hashed_password = password_hash($password, PASSWORD_BCRYPT);
        $profile_picture_name = basename($profile_picture['name']);
        $profile_picture_tmp_name = $profile_picture['tmp_name'];
        $profile_picture_size = $profile_picture['size'];
        $profile_picture_error = $profile_picture['error'];
        $profile_picture_type = $profile_picture['type'];
        $profile_picture_ext = strtolower(pathinfo($profile_picture_name, PATHINFO_EXTENSION));
        $allowed_ext = array('jpg', 'jpeg', 'png', 'gif');

        if (in_array($profile_picture_ext, $allowed_ext)) {
            $profile_picture_new_name = uniqid('', true) . "." . $profile_picture_ext;
            $profile_picture_destination = "../uploads/users/" . $profile_picture_new_name;
            $profile_picture_db_destination = "uploads/users/" . $profile_picture_new_name;

            if (move_uploaded_file($profile_picture_tmp_name, $profile_picture_destination)) {
                $sql = "INSERT INTO users(username, email, password, profile_picture) VALUES (?, ?, ?, ?)";
                $stmt = $conn->prepare($sql);
                try {
                    $stmt->execute([$username, $email, $hashed_password, $profile_picture_db_destination]);
                    header("Location: ../pages/auth/signup.php?success=Bienvenido%20$username%20a%20PixelHub");
                    exit();
                } catch (Exception $e) {
                    header("Location:../pages/auth/signup.php?error=Hemos%20tenido%20un%20error&name=$username&email=$email");
                    exit();
                }
            } else {
                header("Location:../pages/auth/signup.php?error=Error%20al%20guardar%20tu%20foto%20de%20perfil&name=$username&email=$email");
                exit();
            }
        } else {
            header("Location:../pages/auth/signup.php?error=Extensión%20de%20foto%20no%20admitida&name=$username&email=$email");
            exit();
        }
    }
} else {
    header("Location:../index.php");
    exit();
}
?>