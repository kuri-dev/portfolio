<?php
session_start();

if(isset($_POST['enviar'])) {
    // Procesar la subida de una nueva imagen
    if(!empty($_FILES['foto']['name'])) {
        include "../db_conn/config.php";
        include "../functions/funcions.php";

        // Obtener datos del formulario
        $profile_picture = $_FILES['foto'];

        // Procesar la imagen
        // Código para procesar la imagen aquí (similar al controlador de registro)
        $profile_picture_name = basename($profile_picture['name']);
        $profile_picture_tmp_name = $profile_picture['tmp_name'];
        $profile_picture_size = $profile_picture['size'];
        $profile_picture_error = $profile_picture['error'];
        $profile_picture_type = $profile_picture['type'];
        $profile_picture_ext = strtolower(pathinfo($profile_picture_name, PATHINFO_EXTENSION));
        $allowed_ext = array('jpg', 'jpeg', 'png', 'gif');
        // Actualizar la base de datos
        if (in_array($profile_picture_ext, $allowed_ext)) {
            $profile_picture_new_name = uniqid('', true) . "." . $profile_picture_ext;
            $profile_picture_destination = "../uploads/users/" . $profile_picture_new_name;
            $profile_picture_db_destination = "uploads/users/" . $profile_picture_new_name;

            if (move_uploaded_file($profile_picture_tmp_name, $profile_picture_destination)) {
                try {
                    $sql = "UPDATE users SET profile_picture = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$profile_picture_db_destination, $_SESSION['userID']]);

        // Actualizar la variable de sesión
        $_SESSION['userImg'] = $profile_picture_db_destination;

        // Redirigir
        header("Location: ../pages/profile.php?success=true");
        exit();
                } catch (Exception $e) {
                    header("Location: ../pages/profile.php?error=al%20cambiar%20por%20defecto");
        exit();
                }
            }
        }

        
    }
    // Procesar la selección de una imagen predeterminada
    elseif(!empty($_POST['default'])) {
        include "../db_conn/config.php";

        // Obtener la imagen predeterminada seleccionada
        $selected_default_image = $_POST['default'];

        // Actualizar la base de datos
        $sql = "UPDATE users SET profile_picture = ? WHERE id = ?";
        $stmt = $conn->prepare($sql);
        $stmt->execute([$selected_default_image, $_SESSION['userID']]);

        // Actualizar la variable de sesión
        $_SESSION['userImg'] = $selected_default_image;

        // Redirigir
        header("Location: ../pages/profile.php?success=true");
        exit();
    }
    else {
        // Manejar el caso en que no se haya seleccionado ninguna opción
        header("Location: ../pages/profile.php?error=al%20cambiar%20por%20defecto");
        exit();
    }
}
else {
    // Manejar el caso en que el formulario no se haya enviado correctamente
    header("Location: ../pages/profile.php?error=general");
    exit();
}
?>
