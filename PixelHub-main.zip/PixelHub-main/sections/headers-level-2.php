<?php
session_start();
error_reporting(0);
?>
<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- <link rel="stylesheet" href="./styles.css"> -->
    <link rel="shortcut icon" href="./../../assets/img/favicon.ico" type="image/x-icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css"
        integrity="sha512-SnH5WK+bZxgPHs44uWIX+LLJAJ9/2PkPKZ5QiAj6Ta86w+fsb2TkcmfRyVX3pBnMFcV7oQPJkl9QevSCWr3W6A=="
        crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js"
        integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r"
        crossorigin="anonymous"></script>
    <title>PixelHub | Criticas | Recomendaciones | Anime | Peliculas | Tecnología</title>
    <script>
        // Función para obtener los parámetros de la URL
        function getQueryParams() {
            const params = new URLSearchParams(window.location.search);
            return Object.fromEntries(params.entries());
        }

        // Función para contar clics y reproducir audio
        function handleClick() {
            let clickCount = 0;
            const audio = new Audio('./../../assets/audios/Spiderman Theme.mp3'); // Reemplaza 'ruta/al/audio.mp3' con la ruta real del archivo de audio
            audio.volume = 0.2;
            let isPlaying = false;

            const h1Element = document.querySelector('h1.fs-1.display-2.pt-4.text-white.text-center');
            if (!h1Element) return;

            h1Element.addEventListener('click', () => {
                if (isPlaying) return; // Si el audio se está reproduciendo, no contar el clic
                clickCount++;
                if (clickCount === 15) {
                    audio.play();
                    isPlaying = true;
                }
            });

            audio.addEventListener('ended', () => {
                isPlaying = false; // Resetear isPlaying cuando el audio termine
            });
        }

        // Verificar el parámetro 'art' y ejecutar la función si es igual a 7
        document.addEventListener('DOMContentLoaded', () => {
            const queryParams = getQueryParams();
            if (queryParams.art === '7') {
                handleClick();
            }
        });
    </script>

</head>