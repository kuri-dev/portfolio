<?php
include __DIR__ . "/navbar.php";
?>
<style>
  <?php echo file_get_contents("../css/variables.css"); ?>
.bg-color{
background-color: var(--background-color)!important;
}
  </style>
<div class="container-fluid text-center bg-color">
    <h1 class="fs-1 display-2 pt-4 text-white bg-color">Bienvenido a PIXELHUB</h1>
    <div><p class="fs-6 display-6 text-white bg-color">Opiniones • Críticas • Recomendaciones</p></div>
    <div class="container bg-color">
        <div class="row py-0 py-lg-2">
            <div class="col-12 col-lg-4 px-2 py-lg-0 py-2">
                <a href="pages/articles/multiple-articles.php?cat=tech" target="_self" rel="noopener noreferrer">
                    <div class="card text-bg-dark">
                        <img src="assets/img/tech_landing.webp" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <h5 class="card-title her-landing-card">TECH/GADGETS/CODING</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-lg-8 px-2 py-lg-0 py-2">
                <a href="pages/articles/multiple-articles.php?cat=anime" target="_self" rel="noopener noreferrer">
                    <div class="card text-bg-dark" id="longcol">
                        <img src="assets/img/anime&manga_landing.webp" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <h5 class="card-title her-landing-card">ANIME Y MANGA</h5>
                        </div>
                    </div>
                </a>
            </div>
        </div>
        <div class="row py-0 py-lg-2">
            <div class="col-12 col-lg-4 px-2 py-lg-0 py-2">
                <a href="pages/articles/multiple-articles.php?cat=gaming" target="_self" rel="noopener noreferrer">
                    <div class="card text-bg-dark">
                        <img src="assets/img/gaming_landing.webp" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <h5 class="card-title her-landing-card">GAMING</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-lg-4 px-2 py-lg-0 py-2">
                <a href="pages/articles/multiple-articles.php?cat=comics" target="_self" rel="noopener noreferrer">
                    <div class="card text-bg-dark">
                        <img src="assets/img/comics_landing.jfif" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <h5 class="card-title her-landing-card">CÓMIC</h5>
                        </div>
                    </div>
                </a>
            </div>
            <div class="col-12 col-lg-4 px-2 py-lg-0 py-2">
                <a href="pages/articles/multiple-articles.php?cat=cine" target="_self" rel="noopener noreferrer">
                    <div class="card text-bg-dark">
                        <img src="assets/img/cine&serie_landing.webp" class="card-img" alt="...">
                        <div class="card-img-overlay">
                            <h5 class="card-title her-landing-card">CINE Y SERIES</h5>
                        </div>
                    </div>
                </a>
            </div>
        </div>
    </div>
</div>