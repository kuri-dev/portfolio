<!-- usa lo de abajo para guiarte <3 -->
<?php
session_start();
?>
<style>
  <?php echo include_once ("../css/variables.css"); ?>
</style>
<style>
  img.user-image {
    border-radius: 50%;
    width: 50px;
    height: 50px;
  }

  li a.nav-link.px-2.my-active {
    color: var(--primary-green) !important;
  }
  .bg-color{
background-color: var(--background-color)!important;
}
</style>
<div class="container bg-color">
  <header class="d-flex flex-wrap align-items-center justify-content-center justify-content-md-between py-3 bg-color">
    <div class="col-md-3  mb-md-0">
      <a href="index.php" class="d-inline-flex link-body-emphasis text-decoration-none">
        <img class="logonav" src="assets/img/logo_pixelhub.png" alt="">
      </a>
    </div>

    <ul class="nav col-12 col-md-auto justify-content-center mb-md-0">
      <li class="pb-2"><a href="index.php" class="nav-link px-2 my-active">Inicio</a></li>
      <li class="pb-2"><a href="pages/articles/multiple-articles.php" class="nav-link px-2">Feed</a></li>
      <li class="pb-2"><a href="pages/contacto.php" class="nav-link px-2">Contacto</a></li>

      <!-- <li><a href="#" class="nav-link px-2">FAQs</a></li>
        <li><a href="#" class="nav-link px-2">About</a></li> -->
    </ul>

    <?php if (!isset($_SESSION['userImg'])): ?>
      <div class="col-md-3 text-end">
        <a href="pages/auth/login.php"><button type="button" class="btn btn-primary loginbtn me-2">Iniciar
            sesión</button></a>
        <a href="pages/auth/signup.php"><button type="button" class="btn btn-primary registerbtn">Registrarse</button></a>
      </div>
    <?php else: ?>
      <div class="col-md-3 text-end">
        <div class="d-flex flex-row flex-wrap justify-content-end align-items-center me-2">
          <a href="pages/profile.php"><img src="./<?php echo $_SESSION['userImg']; ?>" alt="User Image"
              class="user-image me-2"></a>
          <li class="nav-item dropdown col-md-3 justify-content-center align-items-center d-flex flex-col">
            <a class="nav-link dropdown-toggle" role="button" data-bs-toggle="dropdown" aria-expanded="false">
              <i class="fa-solid fa-bars"></i>
            </a>
            <ul class="dropdown-menu">
              <li><a class="dropdown-item" href="pages/write-article.php">Escribir articulo</a></li>
              <hr class="dropdown-divider">
          </li>
          <li><a class="dropdown-item logoutbtn me-2" href="php/signout.php">Cerrar
              sesión</a></li>
          </ul>
          </li>
        </div>
      </div>
    <?php endif; ?>
  </header>
</div>